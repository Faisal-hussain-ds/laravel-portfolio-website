<section id="resume" class="resume">
    <div class="container">

      <div class="section-title">
        <h2>Resume</h2>
        <p>Check My Resume</p>
      </div>

      <div class="row">
          <div class="col-lg-12">
            
           

            {!! html_entity_decode(Helper::settingValue('resume')) !!}
           
          </div>
      </div>

    </div>
  </section>