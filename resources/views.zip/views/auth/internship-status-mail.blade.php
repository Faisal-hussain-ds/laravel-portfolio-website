<x-guest-layout>
    

    <h1>{{ $mailData['title'] }}</h1>
    <br>
    

    <div class="mb-4 text-sm text-gray-600">
    <p>{{ $mailData['body'] }}</p>
    </div>
  
     
    <p>Thank you</p>
  
</x-guest-layout>
